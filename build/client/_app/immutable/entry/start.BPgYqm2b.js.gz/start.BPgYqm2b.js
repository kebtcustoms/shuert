import{b as a}from"../chunks/entry.BVh6nDbZ.js";export{a as start};
