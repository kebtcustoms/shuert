import{s as x,n as M}from"../chunks/scheduler.NS8L8LGm.js";import{S as k,i as P,m,s as _,e as B,n as d,h as w,c as S,d as b,g as c,o as L,p as g,j as v,t as y,a as f,q as $}from"../chunks/index.OFbx2xAc.js";import{S as A,F as D}from"../chunks/Form.oILZ8vQZ.js";import{A as H,U as V,S as q}from"../chunks/Spacer.Cnxwt_mv.js";function C(u){let t,r,a,o,n,h,l,i,p;return t=new H({props:{productimage:F,component:V,producttitle:T,productdesc:U}}),a=new q({}),n=new A({}),i=new D({props:{products:u[0]}}),{c(){m(t.$$.fragment),r=_(),m(a.$$.fragment),o=_(),m(n.$$.fragment),h=_(),l=B("div"),m(i.$$.fragment),this.h()},l(s){d(t.$$.fragment,s),r=w(s),d(a.$$.fragment,s),o=w(s),d(n.$$.fragment,s),h=w(s),l=S(s,"DIV",{style:!0});var e=b(l);d(i.$$.fragment,e),e.forEach(c),this.h()},h(){L(l,"margin-top","100px")},m(s,e){g(t,s,e),v(s,r,e),g(a,s,e),v(s,o,e),g(n,s,e),v(s,h,e),v(s,l,e),g(i,l,null),p=!0},p:M,i(s){p||(y(t.$$.fragment,s),y(a.$$.fragment,s),y(n.$$.fragment,s),y(i.$$.fragment,s),p=!0)},o(s){f(t.$$.fragment,s),f(a.$$.fragment,s),f(n.$$.fragment,s),f(i.$$.fragment,s),p=!1},d(s){s&&(c(r),c(o),c(h),c(l)),$(t,s),$(a,s),$(n,s),$(i)}}}let F="batterypak",T="Battery Pak",U="Presenting the Shuert Technologies Battery Pak – the ultimate innovation in transporting electric vehicle lithium-ion batteries. Developed through advanced thermoforming technology, each Battery Pak is constructed from High-Molecular weight, High-Density Polyethylene Co-Polymer plastic, which endows these containers with extraordinary lightness and high durability. This superior design transcends the limitations of traditional wooden containers by eliminating concerns over product damage, ongoing repairs, and the environmental burden of wood disposal.";function Z(u){return[[{id:"battery-pak",name:"Battery-Pak",svg:`<svg id="Layer_2" data-name="Layer 2" xmlns="http://www.w3.org/2000/svg" height="68.3" viewBox="0 0 244 68.3">
  <defs>
    <style>
      .cls-1 {
        fill: none;
        // stroke: #d12539;
        stroke-miterlimit: 10;
        stroke-width: 4px;
      }
    </style>
  </defs>
  <g id="Battery_Pack" data-name="Battery Pack">
    <path class="cls-1" d="M109.09,57.47v3.83s.17,2.58-1.67,2.58-2.81,0-2.81,0h-26.09s-.98,0-2.81,0-1.67-2.58-1.67-2.58v-9.58s-.17-2.58,1.67-2.58h28.9s.98,0,2.81,0c1.83,0,1.67,2.58,1.67,2.58v3.83s0,1.92,0,1.92Z"/>
    <path class="cls-1" d="M6.42,61.04s.49.94,2.32.94c0,0,1.5-.08,3.25-1.17l5.25-3.17s3.66-2.75,7.75.08l8.33,5.25s3.01,2,4.42,2.08"/>
    <path class="cls-1" d="M26.26,65.05v-6.45s-.04-.08-.08-.08l-10.4.06c-.06,0-.1.05-.1.1v6.36"/>
    <line class="cls-1" x1="24.39" y1="58.53" x2="24.39" y2="57.34"/>
    <line class="cls-1" x1="17.4" y1="58.53" x2="17.4" y2="57.47"/>
    <polyline class="cls-1" points="64.87 65.05 64.87 66.3 10.66 66.3 10.66 65.22 16.12 65.05"/>
    <polygon class="cls-1" points="9.69 20.57 9.69 19.66 32.07 19.66 32.07 20.53 9.69 20.57"/>
    <path class="cls-1" d="M24.19,19.66V3.45s.02-1.45-1.23-1.45h-1.95s-.23,0-.23,0h-1.95c-1.25,0-1.23,1.45-1.23,1.45v16.21"/>
    <path class="cls-1" d="M134.91,57.47v3.83s-.17,2.58,1.67,2.58h2.81s26.09,0,26.09,0h2.81c1.83,0,1.67-2.58,1.67-2.58v-3.83s0-1.92,0-1.92v-3.83s.17-2.58-1.67-2.58h-2.81s-26.09,0-26.09,0h-2.81c-1.83,0-1.67,2.58-1.67,2.58v5.75Z"/>
    <path class="cls-1" d="M206.93,37.23l2.54-16.7,24.95.04h2.25s2.17,16.66,2.17,16.66c0,0,1.2.46,1.59.97.47.62.74,1.36.82,2.13l.17,1.73c.58,0,.58.29.58.29v.71c0,.17-.5.25-.5.25l-1.67,11.82c-.23,1.65-.75,3.25-1.55,4.72-1.27,2.34-3.49,5.21-6.7,5.21-5.41,0-25.07,0-25.07,0h-71.61s-12.79,0-12.79,0h-.22s-12.79,0-12.79,0H12.41c-3.21,0-5.43-2.87-6.7-5.21-.8-1.47-1.32-3.06-1.55-4.72l-1.67-11.82s-.5-.08-.5-.25v-.71s0-.29.58-.29l.17-1.73c.08-.77.35-1.51.82-2.13.39-.51,1.59-.97,1.59-.97l2.17-16.66h2.25l24.95-.04,2.54,16.7"/>
    <path class="cls-1" d="M237.58,61.04s-.49.94-2.32.94c0,0-1.5-.08-3.25-1.17l-5.25-3.17s-3.66-2.75-7.75.08l-8.33,5.25s-3.01,2-4.42,2.08"/>
    <path class="cls-1" d="M217.74,65.05v-6.45s.04-.08.08-.08l10.4.06c.06,0,.1.05.1.1v6.36"/>
    <line class="cls-1" x1="219.61" y1="58.53" x2="219.61" y2="57.34"/>
    <line class="cls-1" x1="226.6" y1="58.53" x2="226.6" y2="57.47"/>
    <polyline class="cls-1" points="179.13 65.05 179.13 66.3 233.34 66.3 233.34 65.22 227.88 65.05"/>
    <polyline class="cls-1" points="238.83 37.23 122.11 37.23 121.89 37.23 5.17 37.23"/>
    <polygon class="cls-1" points="234.31 20.57 234.31 19.66 211.93 19.66 211.93 20.53 234.31 20.57"/>
    <path class="cls-1" d="M219.81,19.66V3.45s-.02-1.45,1.23-1.45h2.18s.7,0,1.95,0c1.25,0,1.23,1.45,1.23,1.45v16.21"/>
    <g id="Layer_25" data-name="Layer 25">
      <path class="cls-1" d="M24.19,14.41h3.1s1.03,0,1.03,1.25v4"/>
      <path class="cls-1" d="M219.78,14.41h-3.1s-1.03,0-1.03,1.25,0,4,0,4"/>
      <path class="cls-1" d="M24.19,10.83h20.95s3.09,1.33,5.92,1.33h9.09v-1.33h10.41v1.33h2.07"/>
      <path class="cls-1" d="M72.62,12.16h2.25s2.14,0,4.99-1.33h11s10.37,0,10.37,0c2.85,1.33,4.99,1.33,4.99,1.33h2.25s23.59,0,23.59,0v-.67l9.13-1.58h21.98l8.95,1.58v.67h1.03v-1.33h10.44v1.33h9.82s2.14,0,4.99-1.33h21.42"/>
    </g>
  </g>
</svg>

`,selected:!1}]]}class G extends k{constructor(t){super(),P(this,t,Z,C,x,{})}}export{G as component};
